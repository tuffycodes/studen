# DIPTI-Student-Portal
# Output


https://github.com/Niraviman-Singha/DIPTI-Student-Portal/assets/95018959/6fde9cc2-b99d-4804-ba55-16bc70cf8b1d

